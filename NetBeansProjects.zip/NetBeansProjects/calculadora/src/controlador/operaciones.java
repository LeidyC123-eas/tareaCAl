/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

/**
 *
 * @author sistemas
 */
public class operaciones {
    public String sumar(int numero1, int numero2){
        int resultado = numero1 + numero2;
        return resultado+"";
       //return String.valueOf(resultado);
    }
        public String restar (int numero1, int numero2){
            int resultado = numero1 - numero2;
            return resultado+"";
   
        }
        public String dividir (int numero1, int numero2){
            float resultado = numero1 / numero2;
            return resultado+"";
            //float para dividir (menos espacio) 
    }
        public String multiplicar (int numero1, int numero2){
            int resultado = numero1 * numero2;
            return resultado+"";
         }
}